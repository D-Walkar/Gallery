
--
-- Indexes for dumped tables
--

--
-- Indexes for table `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`album_id`);

--
-- Indexes for table `imagesinfo`
--
ALTER TABLE `imagesinfo`
  ADD PRIMARY KEY (`img_id`),
  ADD KEY `album_id` (`album_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `album`
--
ALTER TABLE `album`
  MODIFY `album_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `imagesinfo`
--
ALTER TABLE `imagesinfo`
  MODIFY `img_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `imagesinfo`
--
ALTER TABLE `imagesinfo`
  ADD CONSTRAINT `imagesinfo_ibfk_1` FOREIGN KEY (`album_id`) REFERENCES `album` (`album_id`);

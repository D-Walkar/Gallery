
-- --------------------------------------------------------

--
-- Table structure for table `imagesinfo`
--

CREATE TABLE `imagesinfo` (
  `img_id` int(11) NOT NULL,
  `album_id` int(11) DEFAULT NULL,
  `imgname` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `imagesinfo`
--

INSERT INTO `imagesinfo` (`img_id`, `album_id`, `imgname`) VALUES
(1, 1, 'image1.jpeg'),
(2, 1, 'image2.jpeg'),
(3, 4, 'wild1.jpg'),
(4, 4, 'wild2.jpeg'),
(5, 2, 'candid1.jpeg'),
(6, 1, 'image3.jpeg'),
(8, 4, 'wild3.jpeg'),
(9, 3, 'animals-avian-beach-760984.jpg'),
(16, 3, 'pexels-photo-725255.jpeg'),
(17, 4, 'animal-animal-photography-bird-33101.jpg'),
(18, 2, 'animal-park-animal-photography-animals-814898.jpg');
